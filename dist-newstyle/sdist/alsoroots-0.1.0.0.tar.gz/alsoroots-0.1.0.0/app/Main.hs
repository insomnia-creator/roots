module Main where

import Cryptol.Backend.FloatHelpers (BF (BF, bfExpWidth, bfPrecWidth, bfValue), fpCheckStatus, fpPP)
import Cryptol.TypeCheck.PP (PPFloatFormat (FloatFrac), PPOpts (PPOpts, useAscii, useBase, useFPBase, useFPFormat, useFieldOrder, useInfLength))
import Data.Int (Int64)
import LibBF

by :: IO [Double]
by = fmap (map read . words) getLine

-- functions
-- f :: Double -> Double
-- fp :: Double -> Double
-- f x = x ** 10 + 5 * (x ** 9) + 3 * (x ** 2) + 18

xn :: BigFloat -> Int64 -> BigFloat
xn x n = fpCheckStatus (bfPow (float256 NearEven) x (bfFromInt n))

xy :: BigFloat -> Int64 -> BigFloat
xy x y = fpCheckStatus (bfMul (float256 NearEven) x (bfFromInt y))

xpy :: BigFloat -> BigFloat -> BigFloat
xpy x y = fpCheckStatus (bfAdd (float256 NearEven) x y)

xny :: BigFloat -> BigFloat -> BigFloat
xny x y = fpCheckStatus (bfSub (float256 NearEven) x y)

xby :: BigFloat -> BigFloat -> BigFloat
xby x y = fpCheckStatus (bfDiv (float256 NearEven) x y)

-- x100 + 3x2 + 2x + 10
f :: BigFloat -> BigFloat
f x = xpy (xpy (xn x 87) (xy (xn x 2) 3)) (xpy (xy x 2) (bfFromInt 10))

-- 5x4 + 6x + 2
fp :: BigFloat -> BigFloat
fp x = xpy (xpy (xy (xn x 86) 87) (xy x 6)) (bfFromInt 10)

--- x0 - (f (x0) / f'(x0))
approximate :: BigFloat -> BigFloat
approximate x0 = xny x0 (xby (f x0) (fp x0))

main :: IO ()
main = do
  print "Enter an approximation and times to iterate"
  doubs <- by
  let approxDoub = head doubs
  let its = doubs !! 1
  let approx = bfFromDouble approxDoub
  let approximation = iterate approximate approx !! round its
  let ops = PPOpts {useInfLength = 4, useFieldOrder = maxBound, useAscii = True, useBase = 10, useFPFormat = FloatFrac 256, useFPBase = 10}
  let bf = BF {bfValue = approximation, bfPrecWidth = 256, bfExpWidth = 256}
  print (fpPP ops bf)
